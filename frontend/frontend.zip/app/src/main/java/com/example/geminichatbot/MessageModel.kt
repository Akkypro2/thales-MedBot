package com.example.geminichatbot

data class MessageModel(
    val message : String,
    val role : String
)
