package com.example.geminichatbot

object Constants {
    val apiKey = BuildConfig.API_KEY
}