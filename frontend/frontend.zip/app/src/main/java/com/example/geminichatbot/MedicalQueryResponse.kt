package com.example.geminichatbot

data class MedicalQueryResponse(
    val response: String,
    val sources: List<String>
)
